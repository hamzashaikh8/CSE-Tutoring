import csv

from flask import Flask, render_template, request, redirect, flash, url_for
import smtplib
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from itsdangerous import Serializer
from wtforms import StringField, TextAreaField, PasswordField, BooleanField, SubmitField
from wtforms.fields.html5 import EmailField
from wtforms.validators import InputRequired, Email, Length
import _sqlite3
from sqlalchemy import desc




app = Flask(__name__)
# secret key
app.config['SECRET_KEY'] = 'element'
bootstrap = Bootstrap(app)
subscribers = []


class LoginForm(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=15)])
    password = PasswordField('password', validators=[InputRequired(), Length(min=4, max=20)])


class RegisterForm(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=15)])
    password = PasswordField('password', validators=[InputRequired(), Length(min=4, max=20)])
    email = StringField('email', validators=[InputRequired(), Email(message='Invalid email'), Length(max=50)])
    firstname = StringField('First Name', validators=[InputRequired(), Length(min=4, max=15)])
    lastname = StringField('Last Name', validators=[InputRequired(), Length(min=4, max=15)])
    submit = SubmitField('Sign Up')


class ClassPick(FlaskForm):
    comp248 = BooleanField('comp248')
    comp249 = BooleanField('comp249')
    comp232 = BooleanField('comp232')
    soen228 = BooleanField('soen228')
    soen287 = BooleanField('soen287')


class ForgotPassword(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=20)])
    newpass = StringField('newpass', validators=[InputRequired(), Length(min=4, max=20)])


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = LoginForm()
    if form.validate_on_submit():
        with open('data/usernames.csv', 'r') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:
                if row[0] == form.username.data and row[1] == form.password.data:
                    return render_template("message.html")
                else:
                    flash("Username or Password is incorrect!")
    return render_template('signup.html', form=form)


@app.route('/')
def home():
    return render_template("maincode.html")


@app.route('/maincode')
def maincode():
    return render_template("maincode.html")


@app.route('/Register', methods=['GET', 'POST'])
def register():
    reg = RegisterForm(request.form)
    f = open("data/usernames.csv", "a")
    if reg.validate_on_submit():
        f.write("\n{},{},{},{},{}".format(reg.username.data, reg.password.data, reg.firstname.data, reg.lastname.data,
                                          reg.email.data))
        return redirect(url_for('thanks', subscribers=subscribers, reg=reg))
    return render_template("Register.html", form=reg)


@app.route('/thx', methods=["GET", "POST"])
def thanks():
    print("im here")
    first_name = ''
    last_name = ''
    email = ''
    with open('data/usernames.csv', 'r') as f:
        file = open('data/usernames.csv', "r")
        linelist = file.readlines()
        lastline = linelist[-1].split(",")
        file.close()
        first_name = lastline[2]
        last_name = lastline[3]
        email = lastline[4]
        print(first_name)
        print(last_name)
        print(email)
        message = "You have subscribed to CSE Tutoring's newsLetter"
        try:
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login("contacthamza.shaikh@gmail.com", "@Bismillah123")
            server.sendmail("contacthamza.shaikh@gmail.com", email, message)
        except:
            print("Cannot connect to the gmail")

        subscribers.append(f" {first_name} {last_name} || {email}")
        print(subscribers)

    message = "You have been subscribe to my email newsLetter"
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login("contacthamza.shaikh@gmail.com", "@Bismillah123")
    server.sendmail("contacthamza.shaikh@gmail.com", email, message)
    title = "Thank You!"
    return render_template("thx.html", subscribers=subscribers)


@app.route('/message', methods=['GET', 'POST'])
def message():
    if request.method == 'POST':
        print(request.form.get('mycheckbox'))
        return 'Done'
    return render_template('message.html')


@app.route('/forgotpass', methods=['GET', 'POST'])
def forgotpass():
    frgotpass = ForgotPassword()
    if request.method == 'POST':
        print("frgotpass validated")
        with open('data/usernames.csv', 'r') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:
                print(row[0], row[1], frgotpass.username.data, frgotpass.newpass.data)
                if row[0] == frgotpass.username.data and row[1] == frgotpass.newpass.data:
                    print('Same username and password')
                    flash("Password is the same as before")
                elif row[0] == frgotpass.username.data and row[1] != frgotpass.newpass.data:
                    print('username and password are different! good')
                    row[1] = frgotpass.newpass.data
                    flash("Password has now been changed!")
                else:
                    print("info not in database")
        with open('data/usernames.csv', 'r') as csv_file:
            reader = csv.reader(csv_file)
            for row in reader:  # we will need to verify and replace the new pass
                if row[0] == frgotpass.username.data and row[1] == frgotpass.newpass.data:
                    print("Username and password are the same")
                    flash('Sorry! New Password is identical to Old password')
                elif row[0] == frgotpass.username.data and row[1] != frgotpass.newpass.data:
                    print('username and password are different! goo')
                    row[1] = frgotpass.newpass.data
                else:
                    return redirect(url_for('forgotpass', frgotpass=frgotpass))
        return redirect(url_for(forgotpass))
    return render_template('forgotpass.html', frgotpass=frgotpass)


@app.route('/index')
def quiz():
    return render_template("index.html")


if __name__ == '__main__':
    app.run()
