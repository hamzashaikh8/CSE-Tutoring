from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField

app = Flask(__name__)
app.config['SECRET_KEY']='element'

@app.route('/form')
def form():
    return render_template('')

class SignUpForm(FlaskForm):
    username = StringField('username')
    password = PasswordField('password')
    submit = SubmitField('Sign Up')

